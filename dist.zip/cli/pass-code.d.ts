export declare class CliPassCode {
    readonly value: string;
    static cast(input: string): CliPassCode;
    constructor(value: string);
}
