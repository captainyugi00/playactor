import { CLI } from "clime";
export declare const cli: CLI;
