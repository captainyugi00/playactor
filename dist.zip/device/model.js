"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DeviceCapability = void 0;
var DeviceCapability;
(function (DeviceCapability) {
    DeviceCapability[DeviceCapability["WAKE"] = 0] = "WAKE";
})(DeviceCapability = exports.DeviceCapability || (exports.DeviceCapability = {}));
