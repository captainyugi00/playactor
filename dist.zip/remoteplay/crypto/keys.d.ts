export declare const INIT_KEYS: {
    PS4: number[];
    PS5: number[];
};
export declare const AERO_KEYS: {
    PS4: number[];
    PS5: number[];
};
export declare const AUTH_NONCE_KEYS: {
    PS4: number[];
    PS5: number[];
};
export declare const AUTH_SEED_KEYS: {
    PS4: number[];
    PS5: number[];
};
