import { RemotePlayOutgoingPacket } from "../packets";
export declare class RemotePlayPasscodeResponsePacket extends RemotePlayOutgoingPacket {
    constructor(passCode: string);
}
