export declare const resultsToErrorCodes: {
    [result: number]: string;
};
export declare function resultToErrorCode(result: number): string | undefined;
