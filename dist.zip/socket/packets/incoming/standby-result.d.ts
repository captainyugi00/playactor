import { IncomingResultPacket } from "../base";
import { PacketType } from "../types";
export declare class StandbyResultPacket extends IncomingResultPacket {
    type: PacketType;
}
